const express = require('express');
const router = express.Router();
const Book = require('../models/Book');
const auth = require('../middleware/auth');
router.post('/', auth, async (req,res)=>{
  try{ const b = new Book(req.body); await b.save(); res.json(b); } catch(err){ res.status(500).json({ error: err.message }); }
});
router.get('/', auth, async (req,res)=>{
  try{ const q = req.query.q ? { $or:[{title:new RegExp(req.query.q,'i')},{author:new RegExp(req.query.q,'i')}] } : {}; const books = await Book.find(q); res.json(books);}catch(err){res.status(500).json({error:err.message});}
});
router.put('/:id', auth, async (req,res)=>{ try{ const updated = await Book.findByIdAndUpdate(req.params.id, req.body, { new:true }); res.json(updated);}catch(err){res.status(500).json({error:err.message});} });
router.delete('/:id', auth, async (req,res)=>{ try{ await Book.findByIdAndDelete(req.params.id); res.json({message:'Deleted'});}catch(err){res.status(500).json({error:err.message});} });
module.exports = router;
