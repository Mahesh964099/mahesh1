import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
const API = 'http://localhost:5000/api/transactions';
@Injectable({ providedIn: 'root' })
export class TransactionsService {
  constructor(private http: HttpClient) {}
  async issue(payload:any){ return this.http.post(API+'/issue',payload).toPromise(); }
  async return(payload:any){ return this.http.post(API+'/return',payload).toPromise(); }
  async getTr(){ return this.http.get<any[]>(API).toPromise(); }
}
