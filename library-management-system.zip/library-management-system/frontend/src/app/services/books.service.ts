import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
const API = 'http://localhost:5000/api/books';
@Injectable({ providedIn: 'root' })
export class BooksService {
  constructor(private http: HttpClient) {}
  async getBooks(){ return this.http.get<any[]>(API).toPromise(); }
  async addBook(b:any){ return this.http.post(API,b).toPromise(); }
  async deleteBook(id:string){ return this.http.delete(API+'/'+id).toPromise(); }
}
