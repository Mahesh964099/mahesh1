import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
const API = 'http://localhost:5000/api/students';
@Injectable({ providedIn: 'root' })
export class StudentsService {
  constructor(private http: HttpClient) {}
  async getStudents(){ return this.http.get<any[]>(API).toPromise(); }
  async addStudent(s:any){ return this.http.post(API,s).toPromise(); }
  async deleteStudent(id:string){ return this.http.delete(API+'/'+id).toPromise(); }
}
