import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
const API = 'http://localhost:5000/api/auth';
@Injectable({ providedIn: 'root' })
export class AuthService {
  constructor(private http: HttpClient) {}
  async register(name:string,email:string,password:string){ return this.http.post(API+'/register',{name,email,password}).toPromise(); }
  async login(email:string,password:string){ const res:any = await this.http.post(API+'/login',{email,password}).toPromise(); localStorage.setItem('token', res.token); }
  logout(){ localStorage.removeItem('token'); }
  getToken(){ return localStorage.getItem('token'); }
}
