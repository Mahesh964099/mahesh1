import { Component, OnInit } from '@angular/core';
import { StudentsService } from '../services/students.service';
@Component({ selector:'app-students', templateUrl:'./students.component.html' })
export class StudentsComponent implements OnInit {
  students:any[]=[]; name=''; roll=''; branch='';
  constructor(private ss:StudentsService) {}
  ngOnInit(){ this.load(); }
  async load(){ this.students = await this.ss.getStudents(); }
  async add(){ if(!this.name) return; await this.ss.addStudent({name:this.name,roll:this.roll,branch:this.branch}); this.name=''; this.roll=''; this.branch=''; await this.load(); }
  async remove(id:string){ await this.ss.deleteStudent(id); await this.load(); }
}
