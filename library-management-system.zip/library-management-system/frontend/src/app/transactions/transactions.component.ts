import { Component, OnInit } from '@angular/core';
import { TransactionsService } from '../services/transactions.service';
import { BooksService } from '../services/books.service';
import { StudentsService } from '../services/students.service';
@Component({ selector:'app-transactions', templateUrl:'./transactions.component.html' })
export class TransactionsComponent implements OnInit {
  books:any[]=[]; students:any[]=[]; transactions:any[]=[]; selectedBook=''; selectedStudent='';
  constructor(private ts:TransactionsService, private bs:BooksService, private ss:StudentsService) {}
  ngOnInit(){ this.load(); }
  async load(){ this.books = await this.bs.getBooks(); this.students = await this.ss.getStudents(); this.transactions = await this.ts.getTr(); }
  async issue(){ if(!this.selectedBook||!this.selectedStudent) return; await this.ts.issue({bookId:this.selectedBook, studentId:this.selectedStudent}); await this.load(); }
  async ret(id:string){ await this.ts.return({transactionId:id}); await this.load(); }
}
