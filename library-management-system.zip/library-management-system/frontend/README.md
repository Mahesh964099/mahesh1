# Library Management System

Full-stack scaffold: Angular 19 frontend + Node.js backend + MongoDB

Run backend:
cd backend
npm install
npm start

Run frontend:
cd frontend
npm install
npx ng serve --open

Default .env contains JWT_SECRET=change_this_secret - change in production.
