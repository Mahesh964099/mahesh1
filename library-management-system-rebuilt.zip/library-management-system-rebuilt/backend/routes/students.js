const express = require('express');
const router = express.Router();
const Student = require('../models/Student');
const auth = require('../middleware/auth');
router.post('/', auth, async (req,res)=>{ try{ const s = new Student(req.body); await s.save(); res.json(s);}catch(err){res.status(500).json({error:err.message});} });
router.get('/', auth, async (req,res)=>{ try{ const students = await Student.find(); res.json(students);}catch(err){res.status(500).json({error:err.message});} });
router.delete('/:id', auth, async (req,res)=>{ try{ await Student.findByIdAndDelete(req.params.id); res.json({message:'Deleted'});}catch(err){res.status(500).json({error:err.message});} });
module.exports = router;
