const express = require('express');
const router = express.Router();
const Transaction = require('../models/Transaction');
const Book = require('../models/Book');
const Student = require('../models/Student');
const auth = require('../middleware/auth');
router.post('/issue', auth, async (req,res)=>{
  try{
    const { bookId, studentId } = req.body;
    const book = await Book.findById(bookId); if(!book) return res.status(404).json({message:'Book not found'});
    if(book.available < 1) return res.status(400).json({message:'No copies available'});
    book.available -= 1; await book.save();
    const trx = new Transaction({ book:bookId, student:studentId, issuedBy: req.user.id, status:'Issued' });
    await trx.save();
    res.json(trx);
  }catch(err){ res.status(500).json({ error: err.message }); }
});
router.post('/return', auth, async (req,res)=>{
  try{
    const { transactionId } = req.body;
    const trx = await Transaction.findById(transactionId); if(!trx) return res.status(404).json({message:'Transaction not found'});
    if(trx.status==='Returned') return res.status(400).json({message:'Already returned'});
    trx.status='Returned'; trx.returnDate = new Date(); await trx.save();
    const book = await Book.findById(trx.book); book.available += 1; await book.save();
    res.json(trx);
  }catch(err){ res.status(500).json({ error: err.message }); }
});
router.get('/', auth, async (req,res)=>{
  try{ const tr = await Transaction.find().populate('book student issuedBy'); res.json(tr);}catch(err){res.status(500).json({error:err.message});}
});
module.exports = router;
