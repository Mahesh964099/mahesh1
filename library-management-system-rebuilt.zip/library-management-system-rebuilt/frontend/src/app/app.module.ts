import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatTableModule } from '@angular/material/table';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { BooksComponent } from './books/books.component';
import { StudentsComponent } from './students/students.component';
import { TransactionsComponent } from './transactions/transactions.component';
import { AuthInterceptor } from './services/auth.interceptor';
const routes: Routes = [ { path:'', component: LoginComponent }, { path:'books', component: BooksComponent }, { path:'students', component: StudentsComponent }, { path:'transactions', component: TransactionsComponent } ];
@NgModule({ declarations: [AppComponent, LoginComponent, BooksComponent, StudentsComponent, TransactionsComponent], imports: [BrowserModule, BrowserAnimationsModule, HttpClientModule, FormsModule, ReactiveFormsModule, RouterModule.forRoot(routes), MatInputModule, MatButtonModule, MatCardModule, MatToolbarModule, MatTableModule], providers: [{ provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true }], bootstrap: [AppComponent] })
export class AppModule { }
