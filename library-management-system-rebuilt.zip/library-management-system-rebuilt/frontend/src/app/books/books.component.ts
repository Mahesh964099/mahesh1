import { Component, OnInit } from '@angular/core';
import { BooksService } from '../services/books.service';
@Component({ selector:'app-books', templateUrl:'./books.component.html' })
export class BooksComponent implements OnInit {
  books:any[] = []; title=''; author='';
  constructor(private bs:BooksService) {}
  ngOnInit(){ this.load(); }
  async load(){ this.books = await this.bs.getBooks(); }
  async add(){ if(!this.title) return; await this.bs.addBook({title:this.title,author:this.author}); this.title=''; this.author=''; await this.load(); }
  async remove(id:string){ await this.bs.deleteBook(id); await this.load(); }
}
