import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
@Component({ selector:'app-login', templateUrl:'./login.component.html' })
export class LoginComponent{ email=''; password=''; error=''; constructor(private auth:AuthService, private router:Router){} async login(){ try{ await this.auth.login(this.email,this.password); this.router.navigate(['/books']); }catch(e:any){ this.error = e?.error?.message || 'Login failed'; } } }
