# Library Management System (Rebuilt)

Frontend: Angular 19 (scaffold). Backend: Node.js + Express + MongoDB.

Backend run:
cd backend
npm install
npm run dev

Frontend run:
cd frontend
npm install
npx ng serve --open

.env contains defaults. Change JWT_SECRET for production.
